<!DOCTYPE html>
<html>
    <link rel="stylesheet" href="CSS/upload.css">
<body>
    
    <div class = "nav">
    <nav class="list">
        <p >
        <a href = "mainpage.php" class="navword">MAINPAGE</a>
        <a href = "mainpage.php" class="navword">FRIENDS</a>
        <a href = "mainpage.php" class="navword">MESSSAGES</a>
        <a href = "mainpage.php" class="navword">NOTIFICATIONS</a>
        <a href = "mainpage.php" class="navword">NEWS</a>
        <a href = "signin.php"class="signout"  >SIGN OUT</a>
        </p>
    </nav>
  </div>

    <div >
        <br>
        <br>
        <br>
<form action="upload.php" method="post" enctype="multipart/form-data" >
  <p class="text">Select image to upload:</p>
  <input type="file" name="fileToUpload" id="fileToUpload" class="button1">
    <br>
  <input type="submit" value="Upload Image" name="submit" class="button2">
</form>
    </div>

</body>
</html>