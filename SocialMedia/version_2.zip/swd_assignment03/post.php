<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // collect value of input field
    $name = $_POST['post'];
    if (empty($name)) {
        echo "";
    } else {
        echo $name;
    }
}
?>