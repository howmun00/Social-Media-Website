<!DOCTYPE html>
<html>
    <link rel="stylesheet" href="CSS/mainpage.css">
 <head>
  <title>Main Page</title>
</head>   
    
    <body>
        <div class = "nav">
    <nav class="list">
        <p >
        <a href = "mainpage.php" class="navword">MAINPAGE</a>
        <a href = "mainpage.php" class="navword">FRIENDS</a>
        <a href = "mainpage.php" class="navword">MESSSAGES</a>
        <a href = "mainpage.php" class="navword">NOTIFICATIONS</a>
        <a href = "mainpage.php" class="navword">NEWS</a>
        <a href = "signout.php"class="signout"  >SIGN OUT</a>
        </p>
    </nav>
  </div>
        <br>
        <br>
        <br>
<main>
<!--Left Column-->    
    <section class="left">
        <br>
     <div class = "profilepicture"> 
          <img src="image/female.jpg" >
    </div>  
        <br>
    <div class = "details">
        <p><input type="submit" class="detailsbutton" value="   MY EVENTS" onclick="function1()"></p>
        <p id="myevents" class="hidden"></p>
        <p><input type="submit" class="detailsbutton" value="   MY PHOTOS" onclick="function2()"></p>
        <p id="myphotos" class="hidden"></p>
        <form >
        <p><input type="submit" class="detailsbutton" value="   SETTINGS" ></p>
        </form>

    </div>
    </section>
    
<!--Right Column-->        
    <section class="right">    
    <div class = "friends">
        <p>Friends</p>
        <table >   
        <tr>
            <td>Bibek</td>
            <td class="status"><img src="image/online.png" width="15px" height="15px"> Online</td>
        </tr>
        <tr>
            <td>HowMun</td>
            <td class="status"><img src="image/online.png" width="15px" height="15px"> Online</td>
        </tr>
        <tr>
            <td>Rafael</td>
            <td class="status"><img src="image/offline.png" width="15px" height="15px"> Offline</td>
        </tr>
        <tr>
            <td>Olivia</td>
            <td class="status"><img src="image/online.png" width="15px" height="15px"> Online</td>
        </tr>   
        </table>
    </div>
    
        <br>
        
    <div class = "request">
        <p>Friend Request</p>
        <table>
        <tr>
            <td>Alex</td>
            <td ><input type="image" src="image/accept.png" width="30px" height="15px"></td>
            <td ><input type="image" src="image/decline.png" width="30px" height="15px"></td>
        </tr>
        <tr>
            <td>Nick</td>
            <td ><input type="image" src="image/accept.png" width="30px" height="15px"></td>
            <td ><input type="image" src="image/decline.png" width="30px" height="15px"></td>
        </tr>
        <tr>
            <td>Sarah</td>
            <td ><input type="image" src="image/accept.png" width="30px" height="15px"></td>
            <td ><input type="image" src="image/decline.png" width="30px" height="15px"></td>
        </tr>
        </table>
    </div>
    </section>
    
<!--Center Column-->        
    <section class="center">
    <div class = "postfeed">
        
        <img class="postpic" src="image/female.jpg">
        <p id="date" class="time"></p>
            <script>
            var today = new Date();
            var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
            var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
            var dateTime = date+' '+time;
            document.getElementById("date").innerHTML = dateTime;
            </script>
        
        <form >
            <input type="text" class="text" placeholder="What are you thinking right now?">
            <form >
            <input type="submit" class="postbutton" value="Post">
            </form>
            <form action="uploadindex.php">
            <input type="submit" class="uploadbutton" value="Upload a Picture">
            </form>
            
        </form>
        
    </div>
    <br>
    <div class = "news">
        <br>
        <span class="date">
            <p>3 May 2021</p>
            <p><img src="image/location.png" width="15px" height="15px"> Ireland</p>
        </span>
        <img class="postpic" src="image/male.jpg">
        
        <div class="name">Bibek</div>
        <br>
        <div >
            <div class="box">
                <br>
            <p>Cork is the second largest city in Ireland, located in the south-west of Ireland, in the province of Munster. Following an extension to the city's boundary in 2019, its population is c. 210,000. The city centre is an island positioned between two channels of the River Lee which meet downstream at the eastern end of the city centre, where the quays and docks along the river lead outwards towards Lough Mahon and Cork Harbour, one of the largest natural harbours in the world.
            </p>
            <img src="image/photo1.jpg" class="photo" height="150px" width="300px">
            <img src="image/photo2.jpg" class="photo" height="150px" width="300px">
            </div>
            
            <div class="buttons">
            <input type="submit" class="button" value="Like" id="button">
            <input type="submit" class="button" value="Comment" onclick="comment()"> 
            </div>
            
            <div id="popup" class="modal">

              <!-- Modal content -->
              <div class="modal-content">
                <span class="close">&times;</span>
                <p>You liked this post!</p>
              </div>

            </div>

            <form>
                <input type="text" class="comment" placeholder="Write a comment..." id="comment">
            </form>
            <br>
        </div>
    </div>
    </section>
        
        <section class="center">
        <div class = "news">
        <br>
        <span class="date">
            <p>20 April 2021</p>
            <p><img src="image/location.png" width="15px" height="15px"> Malaysia</p>
        </span>
        <img class="postpic" src="image/female.jpg">
        
        <div class="name">HowMun</div>
        <br>
        <div >
            <div class="box">
                <br>
            <p>Kuala Lumpur, also known as KL is the capital of Malaysia. The words Kuala Lumpur literally mean 'Muddy Confluence'. The metropolis got this nickname because it was founded near the place where the rivers Klang and Gombak intersect (which you can still see just behind Merdeka Square). Over the years Kuala Lumpur grew into an important Asian city. Within Malaysia Kuala Lumpur is seen as the center of the country; 'it happens all' in KL. People from all areas within Malaysia come to KL to find jobs or do business. Tourist love the city as it has numerous great sights and attractions.
            </p>
            <img src="image/photo3.jpg" class="photo" height="150px" width="300px">
            <img src="image/photo4.jpg" class="photo" height="150px" width="300px">
            </div>
            
            <div class="buttons">
            <input type="submit" class="button" value="Like" id="button2">
            <input type="submit" class="button" value="Comment" onclick="comment2()"> 
            </div>
            
            <div id="popup2" class="modal">

              <!-- Modal content -->
              <div class="modal-content">
                  <span class="close">&times;</span>
                <p>You liked this post!</p>
              </div>

            </div>

            <form>
                <input type="text" class="comment" placeholder="Write a comment..." id="comment2">
            </form>
            <br>
        </div>
    </div>
    </section>
    

    
    
</main>  
        <script>
        function function1() {
              document.getElementById("myevents").innerHTML = "You have no events recently.";
                
                var x = document.getElementById("myevents");
              if (x.style.display === "none") {
                x.style.display = "block";
              } else {
                x.style.display = "none";
              }
            }
                
            function function2() {
              document.getElementById("myphotos").innerHTML = "You have no photos.";
                
                var x = document.getElementById("myphotos");
              if (x.style.display === "none") {
                x.style.display = "block";
              } else {
                x.style.display = "none";
              }
            }
            
        function comment(){
            var x = document.getElementById("comment");
              if (x.style.display === "none") {
                x.style.display = "block";
              } else {
                x.style.display = "none";
              }
        }
            
            function comment2(){
            var x = document.getElementById("comment2");
              if (x.style.display === "none") {
                x.style.display = "block";
              } else {
                x.style.display = "none";
              }
        }
            
        
          var modal = document.getElementById("popup");
            var btn = document.getElementById("button");
            var span = document.getElementsByClassName("close")[0]
            btn.onclick = function() {
              modal.style.display = "block";
            }
            span.onclick = function() {
              modal.style.display = "none";
            }
            window.onclick = function(event) {
              if (event.target == modal) {
                modal.style.display = "none";
              } 
        }
            
            var modal = document.getElementById("popup2");
            var btn = document.getElementById("button2");
            var span = document.getElementsByClassName("close")[0]
            btn.onclick = function() {
              modal.style.display = "block";
            }
            span.onclick = function() {
              modal.style.display = "none";
            }
            window.onclick = function(event) {
              if (event.target == modal) {
                modal.style.display = "none";
              } 
        }
            

        
            
        </script>
    
        
        
    
    
    
    </body>
    
</html>

